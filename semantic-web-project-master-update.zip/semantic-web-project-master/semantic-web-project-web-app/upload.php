<?php
require_once 'auth.php';
require_admin_login();

/* ============================================================
 * Helpers
 * ============================================================ */
function turtleString($s) {
    return '"' . addcslashes((string)$s, "\\\"\n\r\t") . '"';
}

function localName($name) {
    return preg_replace('/[^A-Za-z0-9_-]+/', '_', trim($name));
}

function cityExistsInTriplestore($city, $country) {
    $endpoint = 'http://localhost:3030/bike_station_db/query';
    $query = 'PREFIX dbo: <http://dbpedia.org/ontology/> ' .
             'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> ' .
             'ASK { ?city a dbo:city ; rdfs:label ' . turtleString($city) . ' ; dbo:country ' . turtleString($country) . ' . }';
    $response = @file_get_contents($endpoint . '?query=' . urlencode($query) . '&output=json');
    if ($response === false) return false;
    $result = json_decode($response, true);
    return isset($result['boolean']) && $result['boolean'] === true;
}

function loadTurtle($turtle) {
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'POST',
            'header' => "Content-Type: text/turtle; charset=utf-8",
            'content' => $turtle,
            'timeout' => 60
        )
    ));
    $response = @file_get_contents('http://localhost:3030/bike_station_db/data', false, $context);
    return $response !== false;
}

function deleteCityFromTriplestore($city, $country) {
    $endpoint = 'http://localhost:3030/bike_station_db/update';
    $query = 'PREFIX dbo: <http://dbpedia.org/ontology/> ' .
             'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> ' .
             'PREFIX ex: <http://www.example.com/> ' .
             'DELETE { ?city ?p1 ?o1 . ?station ?p2 ?o2 . } ' .
             'WHERE { ?city a dbo:city ; ' .
             '            rdfs:label ' . turtleString($city) . ' ; ' .
             '            dbo:country ' . turtleString($country) . ' . ' .
             '        ?city ?p1 ?o1 . ' .
             '        OPTIONAL { ?city ex:bikeStations ?station . ?station ?p2 ?o2 . } }';
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'POST',
            'header' => "Content-Type: application/sparql-update; charset=utf-8",
            'content' => $query,
            'timeout' => 30
        )
    ));
    $response = @file_get_contents($endpoint, false, $context);
    return $response !== false;
}

function findStationContainer($xml) {
    $queue = array($xml);
    while (!empty($queue)) {
        $node = array_shift($queue);
        foreach ($node->children() as $child) {
            $count = 0;
            foreach ($child->children() as $gc) {
                $count++;
            }
            $count += count($child->attributes());
            if ($count >= 7) {
                return array($node, $child->getName());
            }
        }
        foreach ($node->children() as $child) {
            $queue[] = $child;
        }
    }
    return null;
}

/* Turn a decoded JSON value into a plain string for the CSV / RDF rows. */
function jsonScalar($value) {
    if (is_array($value)) {
        return implode(',', array_map('jsonScalar', $value));
    }
    if (is_bool($value)) {
        return $value ? '1' : '0';
    }
    if ($value === null) {
        return '';
    }
    return (string)$value;
}

/* Find the first array of station-like objects in a decoded JSON document.
 * Station data can live directly in each object (JCDecaux) or one level deep
 * in a nested object such as "fields" (OpenDataSoft) or "properties" (GeoJSON).
 * Returns array($container, $accessorKeyOrNull, $fieldNames). */
function findStationArray($data) {
    $queue = array($data);
    $head = 0;
    while ($head < count($queue)) {
        $node = $queue[$head++];
        if (is_array($node) && array_is_list($node)) {
            foreach ($node as $item) {
                if (is_array($item) && !array_is_list($item)) {
                    $keys = array_keys($item);
                    if (count($keys) >= 7) {
                        return array($node, null, $keys);
                    }
                    foreach ($keys as $k) {
                        if (is_array($item[$k]) && !array_is_list($item[$k]) && count($item[$k]) >= 7) {
                            return array($node, $k, array_keys($item[$k]));
                        }
                    }
                }
            }
        }
        if (is_array($node)) {
            foreach ($node as $value) {
                $queue[] = $value;
            }
        }
    }
    return null;
}

function buildTurtle($city, $country, $rows) {
    $ln = localName($city);
    $cityUri = 'http://dbpedia.org/resource/' . $ln;
    $stations = array();
    $blocks = '';
    for ($i = 0; $i < count($rows); $i++) {
        $r = $rows[$i];
        $uri = 'http://www.example.com/' . $ln . ($i + 1);
        $stations[] = $uri;
        $blocks .= '<' . $uri . '> a <http://dbpedia.org/resource/Bicycle-sharing_system> ;' . "\n" .
                   '    rdfs:label ' . turtleString($r[0]) . " ;\n" .
                   '    dbo:city ' . turtleString($city) . " ;\n" .
                   '    ex:available ' . turtleString($r[3]) . " ;\n" .
                   '    ex:cardPaiement ' . turtleString($r[6]) . " ;\n" .
                   '    ex:free ' . turtleString($r[4]) . " ;\n" .
                   '    ex:total ' . turtleString($r[5]) . " ;\n" .
                   '    geo:lat ' . turtleString($r[1]) . '^^xsd:decimal ;' . "\n" .
                   '    geo:long ' . turtleString($r[2]) . "^^xsd:decimal .\n\n";
    }
    $turtle = "@prefix geo: <http://www.w3.org/2003/01/geo/wgs84_pos#> .\n" .
              "@prefix dbo: <http://dbpedia.org/ontology/> .\n" .
              "@prefix ex: <http://www.example.com/> .\n" .
              "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n" .
              "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n\n";
    $turtle .= '<' . $cityUri . '> a dbo:city ;' . "\n" .
               '    rdfs:label ' . turtleString($city) . " ;\n" .
               '    dbo:country ' . turtleString($country) . " ;\n" .
               '    ex:bikeStations ' . implode(', ', array_map(function ($u) { return '<' . $u . '>'; }, $stations)) . " .\n\n";
    $turtle .= $blocks;
    return $turtle;
}

function processUpload($post, $city, $country) {
    $rows = array();
    if ($post['fileFormat'] == 'csv') {
        $lines = preg_split('/\r\n|\r|\n/', $post['content']);
        $array = array();
        foreach ($lines as $line) {
            if ($line === '' || $line === null) continue;
            $array[] = str_getcsv($line);
        }
        if (empty($array) || empty($array[0])) {
            return array('ok' => false, 'message' => 'The CSV content is empty or could not be parsed.');
        }
        $header = $array[0];
        $attrs = array('attribute1', 'attribute2', 'attribute3', 'attribute4', 'attribute5', 'attribute6', 'attribute7');
        $idx = array();
        foreach ($attrs as $k => $attr) {
            $found = array_search($post[$attr], $header, true);
            $idx[$k] = ($found === false) ? null : $found;
        }
        foreach ($idx as $k => $i) {
            if ($i === null) {
                return array('ok' => false, 'message' => 'One of the mapped attributes was not found in the CSV header.');
            }
        }
        for ($i = 1; $i < sizeof($array); $i++) {
            if (!isset($array[$i]) || count($array[$i]) < 2) continue;
            $row = array();
            for ($k = 0; $k < 7; $k++) $row[] = trim((string)($array[$i][$idx[$k]] ?? ''));
            if (count(array_filter($row, function ($v) { return $v !== ''; })) > 0) {
                $rows[] = $row;
            }
        }
    } else if ($post['fileFormat'] == 'xml') {
        try {
            $xml = new SimpleXMLElement($post['content']);
        } catch (Exception $e) {
            return array('ok' => false, 'message' => 'The XML content could not be parsed: ' . $e->getMessage());
        }
        $found = findStationContainer($xml);
        if ($found === null) {
            return array('ok' => false, 'message' => 'Could not find a repeating station element with at least 7 attributes or child elements in the XML content.');
        }
        list($container, $stationName) = $found;
        $attrs = array('attribute1', 'attribute2', 'attribute3', 'attribute4', 'attribute5', 'attribute6', 'attribute7');
        foreach ($container->children() as $station) {
            if ($station->getName() !== $stationName) continue;
            $row = array();
            foreach ($attrs as $attr) {
                /* Read the value from an XML attribute when the mapped name is an
                 * attribute (e.g. JCDecaux <si na="..." la="..." .../>), otherwise
                 * read it from a child element. */
                if (isset($station[$post[$attr]])) {
                    $value = (string)$station[$post[$attr]];
                } else {
                    $value = (string)$station->{$post[$attr]};
                }
                $row[] = trim($value);
            }
            if (count(array_filter($row, function ($v) { return $v !== ''; })) > 0) {
                $rows[] = $row;
            }
        }
    } else if ($post['fileFormat'] == 'json') {
        $data = json_decode($post['content'], true);
        if ($data === null) {
            return array('ok' => false, 'message' => 'The JSON content could not be parsed.');
        }
        $found = findStationArray($data);
        if ($found === null) {
            return array('ok' => false, 'message' => 'Could not find a repeating station object with at least 7 fields in the JSON content.');
        }
        list($container, $accessor, $keys) = $found;
        $attrs = array('attribute1', 'attribute2', 'attribute3', 'attribute4', 'attribute5', 'attribute6', 'attribute7');
        foreach ($container as $item) {
            if (!is_array($item) || array_is_list($item)) continue;
            $station = ($accessor !== null && isset($item[$accessor]) && is_array($item[$accessor])) ? $item[$accessor] : $item;
            $row = array();
            foreach ($attrs as $attr) {
                $row[] = trim(jsonScalar($station[$post[$attr]] ?? null));
            }
            if (count(array_filter($row, function ($v) { return $v !== ''; })) > 0) {
                $rows[] = $row;
            }
        }
    } else {
        return array('ok' => false, 'message' => 'Unknown file format.');
    }
    if (empty($rows)) {
        return array('ok' => false, 'message' => 'No bike station rows could be extracted from the provided content.');
    }
    return array('ok' => true, 'rows' => $rows);
}

/* ============================================================
 * Request handling
 * ============================================================ */
$message = null;
$city = null;
$country = null;
$isEdit = isset($_REQUEST['edit']) && $_REQUEST['edit'] == '1';
if (isset($_REQUEST['city']) && isset($_REQUEST['country'])) {
    $city = trim($_REQUEST['city']);
    $country = trim($_REQUEST['country']);
}

$submitted = isset($_POST['fileFormat']) && isset($_POST['content']) &&
             isset($_POST['attribute1']) && isset($_POST['attribute2']) &&
             isset($_POST['attribute3']) && isset($_POST['attribute4']) &&
             isset($_POST['attribute5']) && isset($_POST['attribute6']) &&
             isset($_POST['attribute7']);

if ($submitted && $city !== null && $country !== null) {
    if (!$isEdit && cityExistsInTriplestore($city, $country)) {
        $message = 'This city already exists in the triplestore with real time data, please choose another one';
    } else {
        $result = processUpload($_POST, $city, $country);
        if ($result['ok']) {
            /* Write the transformed CSV file next to the other manually added files */
            $manuallyAddedDir = dirname(__DIR__) . '/Manually-added-files/';
            if (!is_dir($manuallyAddedDir)) {
                mkdir($manuallyAddedDir, 0777, true);
            }
            $csvFile = '';
            foreach ($result['rows'] as $row) {
                $csvFile .= implode(',', $row) . "\n";
            }
            @file_put_contents($manuallyAddedDir . $country . "::" . $city . '.txt', $csvFile);

            /* In edit mode, replace the existing dataset */
            if ($isEdit) {
                deleteCityFromTriplestore($city, $country);
            }

            /* Load the generated RDF into the triplestore */
            $turtle = buildTurtle($city, $country, $result['rows']);
            if (loadTurtle($turtle)) {
                header("Location: city.php?city=" . urlencode($city));
                exit();
            }
            $message = 'The parsed file was saved but could not be loaded into the triplestore. Check that Fuseki is running on port 3030.';
        } else {
            $message = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html
    lang="en"
    prefix="ex: http://example.org/
            rdfs: http://www.w3.org/2000/01/rdf-schema#
            geo: http://www.w3.org/2003/01/geo/wgs84_pos#
            xsd: http://www.w3.org/2001/XMLSchema#
            dbo: http://dbpedia.org/ontology/
            dbr: http://dbpedia.org/page/"
>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - <?php echo $isEdit ? 'Edit City Data' : 'Upload New Data'; ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">

    <script src="vendor/js/jquery.min.js?v=3"></script>
    <script src="vendor/js/bootstrap.bundle.min.js?v=3"></script>
    <script type="text/javascript" src="js/rdf.js?v=3"></script>
    <script type="text/javascript" src="js/parsers.js?v=5"></script>
</head>

<body>

<?php
if ($city !== null && $country !== null) {
    echo '<input type="hidden" id="cityName" value="' . htmlspecialchars($city) . '">';
    echo '<input type="hidden" id="countryName" value="' . htmlspecialchars($country) . '">';

    if ($message !== null) {
        echo '<script>alert(' . json_encode($message) . ');</script>';
    } else if (!$submitted && !$isEdit && cityExistsInTriplestore($city, $country)) {
        ?>
        <script>cityAlreadyExists()</script>
        <?php
    }
} else {
    header("Location: index.php");
    exit();
}
?>

    <!-- Navigation Header -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <a href="admin.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-user-shield mr-1"></i> Admin
                </a>
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-house mr-1"></i> Home
                </a>
                <a href="info.php" class="btn btn-outline-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-circle-info mr-1"></i> Our Info
                </a>
            </div>
        </div>
    </nav>

    <header class="hero hero-sm">
        <i class="fa-solid fa-cloud-arrow-up hero-ghost"></i>
        <h1><?php echo $isEdit ? 'Edit City Data' : 'Upload New City Data'; ?></h1>
        <p><?php echo $isEdit ? 'Replace the existing dataset in the triplestore with updated raw content.' : 'Transform raw XML, CSV or JSON content into linked data and load it into the triplestore.'; ?></p>
    </header>

    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <?php if ($isEdit) { ?>
                <div class="mb-3">
                    <a href="admin.php" class="btn btn-outline-primary btn-sm rounded-pill" onclick="if (document.referrer) { event.preventDefault(); history.back(); }">
                        <i class="fa-solid fa-arrow-left mr-1"></i> Back
                    </a>
                </div>
                <?php } ?>
                <form name="userForm" action="upload.php" method="POST">
                    <?php if ($isEdit) { ?>
                    <input type="hidden" name="edit" value="1">
                    <?php } ?>
                    <?php if ($country !== null && $city !== null) { ?>
                    <input type="hidden" name="country" value="<?php echo htmlspecialchars($country); ?>">
                    <input type="hidden" name="city" value="<?php echo htmlspecialchars($city); ?>">
                    <?php } ?>
                    <div id="div">
                        <!-- Step 1: Upload Raw Content -->
                        <div class="card" id="uploadData">
                            <div class="card-header-custom d-flex align-items-center">
                                <span class="step-badge">1</span>
                                <h2>Upload Raw Data Content</h2>
                            </div>
                            <div class="card-body p-4">
                                <div class="form-group mb-4">
                                    <label for="fileFormat" class="font-weight-600 text-dark small mb-1">File Format</label>
                                    <select id="fileFormat" name="fileFormat" class="custom-select" required>
                                        <option selected value="">Choose a file format</option>
                                        <option value="xml">XML</option>
                                        <option value="csv">CSV</option>
                                        <option value="json">JSON</option>
                                    </select>
                                </div>

                                <div class="form-group mb-4">
                                    <label for="content" class="font-weight-600 text-dark small mb-1">Data Content (Raw XML / CSV / JSON)</label>
                                    <textarea name="content" id="content" class="form-control" rows="8" placeholder="Paste your raw file content here..." required></textarea>
                                </div>

                                <button type="button" class="btn btn-primary-custom" onclick="parser()">
                                    <i class="fa-solid fa-gears mr-1"></i> Parse & Extract Attributes
                                </button>
                            </div>
                        </div>

                        <!-- Step 2: Define Attributes -->
                        <div class="card" id="specifyAttributes" style="display:none;">
                            <div class="card-header-custom d-flex align-items-center">
                                <span class="step-badge">2</span>
                                <h2>Define Uploaded File's Attributes</h2>
                            </div>
                            <div class="card-body p-4">
                                <p class="text-muted small mb-4">Map the extracted attributes from your file to the semantic data fields below.</p>

                                <!-- Mapping Item 1 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute1" name="attribute1" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning1" name="attributeMeaning1" class="form-control bg-white" type="text" value="Bike station name" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 2 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute2" name="attribute2" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning2" name="attributeMeaning2" class="form-control bg-white" type="text" value="Latitude" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 3 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute3" name="attribute3" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning3" name="attributeMeaning3" class="form-control bg-white" type="text" value="Longitude" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 4 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute4" name="attribute4" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning4" name="attributeMeaning4" class="form-control bg-white" type="text" value="Available bikes" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 5 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute5" name="attribute5" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning5" name="attributeMeaning5" class="form-control bg-white" type="text" value="Free spots" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 6 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute6" name="attribute6" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning6" name="attributeMeaning6" class="form-control bg-white" type="text" value="Total spots" disabled>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mapping Item 7 -->
                                <div class="attribute-row">
                                    <div class="form-row align-items-center">
                                        <div class="col-md-6 mb-2 mb-md-0">
                                            <label class="font-weight-600 small text-muted mb-1">Source Attribute</label>
                                            <select id="attribute7" name="attribute7" class="custom-select" required>
                                                <option selected value="">Choose an attribute</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="font-weight-600 small text-muted mb-1">Target Mapping</label>
                                            <input id="attributeMeaning7" name="attributeMeaning7" class="form-control bg-white" type="text" value="Payment method" disabled>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-4 text-right">
                                    <button type="button" name="btnSubmit" class="btn btn-success-custom" onclick="verifyFormParams()">
                                        <i class="fa-solid fa-check mr-1"></i> Save & Process Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

</body>
</html>
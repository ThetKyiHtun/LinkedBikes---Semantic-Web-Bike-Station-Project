<?php
require_once 'auth.php';
require_admin_login();

$adminName = isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'Administrator';
?>
<!DOCTYPE html>
<html lang="en"
      prefix="ex: http://example.org/
              rdfs: http://www.w3.org/2000/01/rdf-schema#
              geo: http://www.w3.org/2003/01/geo/wgs84_pos#
              xsd: http://www.w3.org/2001/XMLSchema#
              dbo: http://dbpedia.org/ontology/
              dbr: http://dbpedia.org/page/">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - Admin Panel</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">

    <script src="vendor/js/jquery.min.js?v=3"></script>
    <script src="vendor/js/bootstrap.bundle.min.js?v=3"></script>
    <script type="text/javascript" src="js/rdf.js?v=3"></script>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <span class="text-light small mr-3">
                    <i class="fa-solid fa-user-shield mr-1"></i><?php echo htmlspecialchars($adminName); ?>
                </span>
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-house mr-1"></i> Home
                </a>
                <a href="logout.php" class="btn btn-outline-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-right-from-bracket mr-1"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <header class="hero hero-sm">
        <i class="fa-solid fa-user-shield hero-ghost"></i>
        <h1><i class="fa-solid fa-shield-halved mr-2"></i>Admin Panel</h1>
        <p>Add new city bike station data into the triplestore repository.</p>
    </header>

    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header-custom">
                        <span class="section-icon icon-green"><i class="fa-solid fa-cloud-arrow-up"></i></span>
                        <h2>Add New City Data</h2>
                    </div>
                    <div class="card-body p-4">
                        <p class="text-muted small mb-4">Enter the name of the country and the city you want to add. You will then paste the raw XML, CSV or JSON content, map its attributes, and load the generated linked data into the triplestore.</p>

                        <form method="GET" action="upload.php">
                            <div class="form-group">
                                <label for="country" class="font-weight-600 text-dark small mb-1">Country Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-globe"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="country" name="country" placeholder="e.g. Myanmar" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="city" class="font-weight-600 text-dark small mb-1">City Name</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-city"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="city" name="city" placeholder="e.g. Mandalay" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success-custom btn-block mt-4">
                                <i class="fa-solid fa-upload mr-1"></i> Continue to Add Data
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header-custom d-flex justify-content-between align-items-center flex-wrap">
                        <div class="d-flex align-items-center">
                            <span class="section-icon icon-blue mr-2"><i class="fa-solid fa-database"></i></span>
                            <h2>Existing Data</h2>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" onclick="loadExistingData()">
                            <i class="fa-solid fa-rotate mr-1"></i> Refresh
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <div class="px-3 pt-3 pb-1">
                            <span class="text-muted small"><i class="fa-solid fa-city mr-1"></i>Total cities in triplestore: <strong id="existingDataCount">-</strong></span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover table-striped mb-0 text-center">
                                <thead>
                                    <tr>
                                        <th>Country</th>
                                        <th>City</th>
                                        <th>Stations</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="existingDataBody">
                                    <tr><td colspan="3" class="text-center text-muted py-4">Loading existing data...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

    <script>
        function escapeHtml(value) {
            var div = document.createElement('div');
            div.appendChild(document.createTextNode(value));
            return div.innerHTML;
        }

        function loadExistingData() {
            var query = "PREFIX dbo: <http://dbpedia.org/ontology/>" +
                        "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" +
                        "SELECT ?country ?city ?label (COUNT(?station) AS ?stations) WHERE {" +
                        "  ?city a dbo:city ;" +
                        "        rdfs:label ?label ;" +
                        "        dbo:country ?country ." +
                        "  OPTIONAL { ?city <http://www.example.com/bikeStations> ?station . }" +
                        "} GROUP BY ?country ?city ?label ORDER BY ?country ?label";

            var url = getFusekiUrl() + "?query=" + encodeURIComponent(query) + "&output=json";

            var body = document.getElementById('existingDataBody');
            var count = document.getElementById('existingDataCount');
            body.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-4">Loading existing data...</td></tr>';

            $.getJSON(url, function (jsonData) {
                var bindings = jsonData.results.bindings;
                body.innerHTML = "";

                if (bindings.length === 0) {
                    body.innerHTML = '<tr><td colspan="4" class="text-center text-muted py-4">No cities found in the triplestore.</td></tr>';
                    count.textContent = "0";
                    return;
                }

                count.textContent = bindings.length;
                var total = 0;
                for (var i = 0; i < bindings.length; i++) {
                    var b = bindings[i];
                    var stationCount = parseInt(b.stations ? b.stations.value : "0", 10);
                    total += stationCount;

                    let country = b.country.value;
                    let cityLabel = b.label.value;

                    var row = document.createElement('tr');
                    var link = "city.php?city=" + encodeURIComponent(cityLabel);
                    row.innerHTML =
                        '<td class="text-muted">' + escapeHtml(country) + '</td>' +
                        '<td><a href="' + link + '">' + escapeHtml(cityLabel) + '</a></td>' +
                        '<td class="font-weight-600">' + stationCount + '</td>';

                    var actions = document.createElement('td');
                    actions.className = "text-nowrap";

                    var editLink = document.createElement('a');
                    editLink.className = "btn btn-outline-primary btn-sm mx-1";
                    editLink.setAttribute('href', 'upload.php?country=' + encodeURIComponent(country) +
                        '&city=' + encodeURIComponent(cityLabel) + '&edit=1');
                    editLink.setAttribute('title', 'Edit ' + cityLabel);
                    editLink.innerHTML = '<i class="fa-solid fa-pen mr-1"></i> Edit';
                    actions.appendChild(editLink);

                    var delBtn = document.createElement('button');
                    delBtn.type = "button";
                    delBtn.className = "btn btn-outline-danger btn-sm mx-1";
                    delBtn.setAttribute('title', 'Delete ' + cityLabel);
                    delBtn.innerHTML = '<i class="fa-solid fa-trash mr-1"></i> Delete';
                    delBtn.addEventListener('click', function () {
                        deleteCity(cityLabel, country);
                    });
                    actions.appendChild(delBtn);

                    row.appendChild(actions);
                    body.appendChild(row);
                }

                var footer = document.createElement('tr');
                footer.innerHTML = '<td colspan="3" class="text-right font-weight-bold text-secondary">Total bike stations</td>' +
                                   '<td class="font-weight-bold text-secondary">' + total + '</td>';
                body.appendChild(footer);
            }).fail(function () {
                body.innerHTML = '<tr><td colspan="4" class="text-center text-danger py-4">Failed to reach the Fuseki endpoint at ' + escapeHtml(getFusekiUrl()) + '. Check if Fuseki is running and reachable.</td></tr>';
                count.textContent = "0";
            });
        }

        function deleteCity(city, country) {
            if (!window.confirm('Delete "' + city + '" (' + country + ')?\nThis will permanently remove the city and all of its bike stations from the triplestore.')) {
                return;
            }

            $.post('delete.php', { city: city, country: country }, function (resp) {
                if (resp.ok) {
                    alert(resp.message || 'City deleted from the triplestore.');
                    loadExistingData();
                } else {
                    alert(resp.message || 'Failed to delete the city.');
                }
            }, 'json').fail(function () {
                alert('Failed to reach delete.php. Check that the web server is running.');
            });
        }

        $(document).ready(function () {
            loadExistingData();
        });
    </script>
</body>
</html>
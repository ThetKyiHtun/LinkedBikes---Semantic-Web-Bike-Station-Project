<!DOCTYPE html>
<html lang="en"
      prefix="ex: http://example.org/
              rdfs: http://www.w3.org/2000/01/rdf-schema#
              geo: http://www.w3.org/2003/01/geo/wgs84_pos#
              xsd: http://www.w3.org/2001/XMLSchema#
              dbo: http://dbpedia.org/ontology/
              dbr: http://dbpedia.org/page/">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - City Stations</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">

    <script src="vendor/js/jquery.min.js?v=3"></script>
    <script src="vendor/js/bootstrap.bundle.min.js?v=3"></script>
    <script type="text/javascript" src="js/rdf.js?v=3"></script>
    <script type="text/javascript" src="js/parsers.js?v=5"></script>
</head>

<body id="body">

    <?php
    if (isset($_GET['city'])) {
        echo '<input type="hidden" id="cityName" value="'.htmlspecialchars($_GET['city']).'">';
    } else {
        header("Location: index.php");
        exit();
    }
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-house mr-1"></i> Home
                </a>
                <a href="info.php" class="btn btn-outline-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-circle-info mr-1"></i> Our Info
                </a>
            </div>
        </div>
    </nav>

    <header class="hero hero-sm">
        <i class="fa-solid fa-bicycle hero-ghost"></i>
        <h1><i class="fa-solid fa-city mr-2"></i><span id="heroCity">Bike Stations</span></h1>
        <p>Live bike station availability and locations</p>
    </header>

    <div class="container py-4">
        <div class="card mb-4">
            <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                <div class="d-flex align-items-center mb-2 mb-md-0">
                    <span class="section-icon icon-blue mr-2"><i class="fa-solid fa-earth-americas"></i></span>
                    <span class="font-weight-bold text-secondary">Data Controls</span>
                </div>
                <div id="getDataIndex" class="d-flex align-items-center">
                    <!-- Dropdowns dynamically populated by getAllCountries() -->
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table id="table" class="table table-hover table-striped mb-0 text-center">
                        <thead id="tableHead">
                            <!-- Populated dynamically via getCityInfo() -->
                        </thead>
                        <tbody id="tableBody">
                            <!-- Rows inserted dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

    <script>
        $(document).ready(function() {
            var heroCity = document.getElementById('heroCity');
            var cityInput = document.getElementById('cityName');
            if (heroCity && cityInput && cityInput.value) {
                heroCity.textContent = cityInput.value;
            }
            getAllCountries();
            getCityInfo();
        });
    </script>
</body>
</html>

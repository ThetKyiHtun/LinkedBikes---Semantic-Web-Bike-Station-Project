<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_admin_logged_in() {
    return !empty($_SESSION['admin_logged_in']);
}

function require_admin_login() {
    if (!is_admin_logged_in()) {
        header('Location: login.php');
        exit();
    }
}
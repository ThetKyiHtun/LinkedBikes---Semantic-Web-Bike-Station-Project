<!DOCTYPE html>
<html
    lang="en"
    prefix="ex: http://example.org/
            rdfs: http://www.w3.org/2000/01/rdf-schema#
            geo: http://www.w3.org/2003/01/geo/wgs84_pos#
            xsd: http://www.w3.org/2001/XMLSchema#
            dbo: http://dbpedia.org/ontology/
            dbr: http://dbpedia.org/page/"
>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - Home</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">

    <script src="vendor/js/jquery.min.js?v=3"></script>
    <script src="vendor/js/bootstrap.bundle.min.js?v=3"></script>
    <script type="text/javascript" src="js/rdf.js?v=3"></script>
</head>

<body onload="getAllCountries()">

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <a href="admin.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-user-shield mr-1"></i> Admin
                </a>
                <a href="info.php" class="btn btn-outline-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-circle-info mr-1"></i> Our Info
                </a>
            </div>
        </div>
    </nav>

    <header class="hero">
        <i class="fa-solid fa-bicycle hero-ghost"></i>
        <h1>LinkedBikes</h1>
        <p>Explore real-time bike station availability across cities.</p>
    </header>

    <div class="container">
        <div class="row justify-content-center my-4">
            <!-- Browse Data Card -->
            <div class="col-md-10 col-lg-8">
                <div class="card card-hover h-100">
                    <div class="card-header-custom">
                        <span class="section-icon icon-blue"><i class="fa-solid fa-database"></i></span>
                        <h2>Explore Existing Data</h2>
                    </div>
                    <div class="card-body">
                        <p class="text-muted small">Select a country and city to view real-time bike station availability and locations.</p>
                        <div id="getDataIndex"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

</body>
</html>

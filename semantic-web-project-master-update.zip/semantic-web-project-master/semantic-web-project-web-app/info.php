<!DOCTYPE html>
<html lang="en"
      prefix="ex: http://example.org/
              rdfs: http://www.w3.org/2000/01/rdf-schema#
              geo: http://www.w3.org/2003/01/geo/wgs84_pos#
              xsd: http://www.w3.org/2001/XMLSchema#
              dbo: http://dbpedia.org/ontology/
              dbr: http://dbpedia.org/page/">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - Our Info</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">

    <script src="vendor/js/jquery.min.js?v=3"></script>
    <script src="vendor/js/bootstrap.bundle.min.js?v=3"></script>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-house mr-1"></i> Home
                </a>
                <a href="info.php" class="btn btn-light btn-sm rounded-pill ml-2">
                    <i class="fa-solid fa-circle-info mr-1"></i> Our Info
                </a>
            </div>
        </div>
    </nav>

    <header class="hero hero-sm">
        <i class="fa-solid fa-bicycle hero-ghost"></i>
        <h1><i class="fa-solid fa-circle-info mr-2"></i>Our Info</h1>
        <p>Contact and developer information for the LinkedBikes team</p>
    </header>

    <div class="container py-4">
        <div class="row">
            <!-- Contact Information -->
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="card card-hover h-100">
                    <div class="card-header-custom">
                        <span class="section-icon icon-blue"><i class="fa-solid fa-address-book"></i></span>
                        <h2>Contact Us</h2>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled mb-0">
                            <li class="d-flex align-items-center py-2 border-bottom">
                                <span class="section-icon icon-blue mr-3"><i class="fa-solid fa-envelope"></i></span>
                                <div>
                                    <div class="text-muted small">Email</div>
                                    <span class="font-weight-600 text-dark">linkedbikes@gmail.com</span>
                                </div>
                            </li>
                            <li class="d-flex align-items-center py-2 border-bottom">
                                <span class="section-icon icon-green mr-3"><i class="fa-solid fa-phone"></i></span>
                                <div>
                                    <div class="text-muted small">Phone</div>
                                    <span class="font-weight-600 text-dark">+95 9 698 981 767</span>
                                </div>
                            </li>
                            <li class="d-flex align-items-center py-2 border-bottom">
                                <span class="section-icon icon-blue mr-3"><i class="fa-solid fa-location-dot"></i></span>
                                <div>
                                    <div class="text-muted small">Address</div>
                                    <span class="font-weight-600 text-dark">University of Computer Studies, Yangon (UCSY), Myanmar</span>
                                </div>
                            </li>
                            <li class="d-flex align-items-center py-2">
                                <span class="section-icon icon-green mr-3"><i class="fa-solid fa-globe"></i></span>
                                <div>
                                    <div class="text-muted small">Website</div>
                                    <span class="font-weight-600 text-dark">linkedbikes-web.org</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Developer Information -->
            <div class="col-lg-6">
                <div class="card card-hover h-100">
                    <div class="card-header-custom">
                        <span class="section-icon icon-green"><i class="fa-solid fa-laptop-code"></i></span>
                        <h2>Developers</h2>
                    </div>
                    <div class="card-body">
                        <p class="text-muted small">
                            LinkedBikes is developed by UCSY Master Students as a Semantic Web
                            engineering project, using Apache Jena Fuseki as the SPARQL triplestore
                            backend.
                        </p>
                        <ul class="list-unstyled mb-0">
                            <li class="d-flex align-items-center py-2 border-bottom">
                                <span class="section-icon icon-blue mr-3"><i class="fa-solid fa-user-tie"></i></span>
                                <div>
                                    <div class="text-muted small">Project Supervisor</div>
                                    <span class="font-weight-600 text-dark">Dr. Tin Zar Thaw</span>
                                </div>
                            </li>
                            <li class="d-flex align-items-center py-2 border-bottom">
                                <span class="section-icon icon-green mr-3"><i class="fa-solid fa-users"></i></span>
                                <div>
                                    <div class="text-muted small">Development Team</div>
                                    <span class="font-weight-600 text-dark">Thet Kyi Htun, Htet Myet Aung, Khin Nadi Kyaw, Nann Su Wai</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

</body>
</html>

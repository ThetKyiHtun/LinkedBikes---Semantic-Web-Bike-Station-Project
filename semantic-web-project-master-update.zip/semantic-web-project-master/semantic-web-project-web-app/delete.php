<?php
require_once 'auth.php';
require_admin_login();

function turtleString($s) {
    return '"' . addcslashes((string)$s, "\\\"\n\r\t") . '"';
}

function deleteCityFromTriplestore($city, $country) {
    $endpoint = 'http://localhost:3030/bike_station_db/update';
    $query = 'PREFIX dbo: <http://dbpedia.org/ontology/> ' .
             'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> ' .
             'PREFIX ex: <http://www.example.com/> ' .
             'DELETE { ?city ?p1 ?o1 . ?station ?p2 ?o2 . } ' .
             'WHERE { ?city a dbo:city ; ' .
             '            rdfs:label ' . turtleString($city) . ' ; ' .
             '            dbo:country ' . turtleString($country) . ' . ' .
             '        ?city ?p1 ?o1 . ' .
             '        OPTIONAL { ?city ex:bikeStations ?station . ?station ?p2 ?o2 . } }';
    $context = stream_context_create(array(
        'http' => array(
            'method' => 'POST',
            'header' => "Content-Type: application/sparql-update; charset=utf-8",
            'content' => $query,
            'timeout' => 30
        )
    ));
    $response = @file_get_contents($endpoint, false, $context);
    return $response !== false;
}

$result = array('ok' => false, 'message' => 'Invalid request.');

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['city']) && isset($_POST['country'])) {
    $city = trim($_POST['city']);
    $country = trim($_POST['country']);

    if ($city === '' || $country === '') {
        $result = array('ok' => false, 'message' => 'City and country are required.');
    } else if (deleteCityFromTriplestore($city, $country)) {
        $csvFile = dirname(__DIR__) . '/Manually-added-files/' . $country . '::' . $city . '.txt';
        if (is_file($csvFile)) {
            @unlink($csvFile);
        }
        $turtleFile = dirname(__DIR__) . '/turtle-files/' . $city . '.ttl';
        if (is_file($turtleFile)) {
            @unlink($turtleFile);
        }
        $result = array('ok' => true, 'message' => 'City "' . $city . '" and its bike stations were deleted from the triplestore.');
    } else {
        $result = array('ok' => false, 'message' => 'Could not reach the triplestore. Check that Fuseki is running on port 3030.');
    }
}

header('Content-Type: application/json');
echo json_encode($result);
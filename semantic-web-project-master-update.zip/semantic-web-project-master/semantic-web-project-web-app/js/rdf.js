/* Taken from stackoverflow */
function pagination(NumberOfRows) {
    $('#pagination').remove();
    /* Place the pagination outside the scrollable table wrapper so it is
     * never clipped, and can be reached by scrolling to the bottom. */
    $('#table').closest('.table-responsive').after(
        '<div id="pagination" class="d-flex justify-content-center my-4"></div>'
    );

    var rowsShown = 5;
    var rowsTotal = NumberOfRows;
    var numPages = Math.ceil(rowsTotal / rowsShown);
    var currentPage = 0;

    function pageLink(rel, html, active) {
        var btn = $('<a href="#" class="btn btn-sm btn-outline-primary mx-1" rel="' + rel + '">' + html + '</a>');
        if (active) {
            btn.addClass('active btn-primary text-white').removeClass('btn-outline-primary');
        }
        return btn;
    }

    function build() {
        var container = $('#pagination');
        container.empty();

        /* Previous */
        container.append(pageLink(currentPage - 1, '<i class="fa-solid fa-chevron-left"></i>'));
        if (currentPage === 0) {
            container.find('a:first').addClass('disabled').attr('tabindex', -1);
        }

        /* Window of page numbers around the current page */
        var start = Math.max(0, currentPage - 2);
        var end = Math.min(numPages - 1, currentPage + 2);

        if (start > 0) {
            container.append('<span class="align-self-center text-muted small mx-1">…</span>');
        }
        for (var i = start; i <= end; i++) {
            container.append(pageLink(i, i + 1, i === currentPage));
        }
        if (end < numPages - 1) {
            container.append('<span class="align-self-center text-muted small mx-1">…</span>');
        }

        /* Next */
        container.append(pageLink(currentPage + 1, '<i class="fa-solid fa-chevron-right"></i>'));
        if (currentPage === numPages - 1) {
            container.find('a:last').addClass('disabled').attr('tabindex', -1);
        }

        container.find('a').on('click', function (e) {
            e.preventDefault();
            var rel = parseInt($(this).attr('rel'), 10);
            if (isNaN(rel) || rel < 0 || rel >= numPages) {
                return;
            }
            currentPage = rel;
            var startItem = currentPage * rowsShown;
            var endItem = startItem + rowsShown;
            $('#table tbody tr').css('opacity', '0.0').hide().
                slice(startItem, endItem).css('display', 'table-row').animate({ opacity: 1 }, 300);
            build();
        });
    }

    build();

    /* Show the first page of rows */
    $('#table tbody tr').hide();
    $('#table tbody tr').slice(0, rowsShown).show();
}

/* Build the Fuseki SPARQL endpoint URL from the page's own host, so the app
 * works whether the site is opened via localhost, an IP or a hostname.
 * Fall back to localhost if no hostname is available. */
function getFusekiUrl() {
    var host = window.location.hostname || "localhost";
    return "http://" + host + ":3030/bike_station_db";
}

function getAllCountries() {
    var query = "PREFIX dbo: <http://dbpedia.org/ontology/>" +
        "SELECT DISTINCT ?country WHERE {" +
        "?city a dbo:city ." +
        "?city dbo:country ?country ." +
        "} " +
        " ORDER BY ?country";

    var responseUrl = getFusekiUrl() + "?query=" + encodeURIComponent(query) + "&output=json";

    $.getJSON(responseUrl, function (jsonData) {
        var bindings = jsonData.results.bindings;
        var container = document.getElementById("getDataIndex");

        if (!container) return;
        container.innerHTML = ""; // Clear existing setup text

        if (bindings.length > 0) {
            var list = document.createElement('select');
            list.setAttribute("id", "countriesList");
            list.setAttribute("class", "custom-select custom-select-sm");
            list.setAttribute("onchange", "getSelectedCountry()");
            list.innerHTML = '<option selected disabled> Select a country </option>';

            for (var i = 0; i < bindings.length; i++) {
                var country = document.createElement('option');
                country.setAttribute("id", bindings[i].country.value);
                country.setAttribute("value", bindings[i].country.value);
                country.appendChild(document.createTextNode(bindings[i].country.value));
                list.appendChild(country);
            }
            container.appendChild(list);
        } else {
            container.innerHTML = "<span class='text-muted small'>No countries found in triplestore.</span>";
        }
    }).fail(function() {
        console.error("Could not query Fuseki at " + getFusekiUrl());
    });
}

function getAllCities(country) {
    var query = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" +
        "PREFIX dbo: <http://dbpedia.org/ontology/>" +
        "SELECT ?label WHERE {" +
        "  ?city a dbo:city ." +
        "  ?city rdfs:label ?label ." +
        "  ?city dbo:country \"" + country + "\" ." +
        "} " +
        " ORDER BY ?label";

    var responseUrl = getFusekiUrl() + "?query=" + encodeURIComponent(query) + "&output=json";

    $.getJSON(responseUrl, function (jsonData) {
        var bindings = jsonData.results.bindings;
        var container = document.getElementById("getDataIndex");

        if (document.getElementById('citiesList') !== null) {
            $('#citiesList').remove();
        }

        var list = document.createElement('select');
        list.setAttribute("id", "citiesList");
        list.setAttribute("class", "custom-select custom-select-sm ml-2");
        list.setAttribute("onchange", "getSelectedCity()");
        list.innerHTML = '<option selected disabled> Select a city </option>';

        for (var i = 0; i < bindings.length; i++) {
            var city = document.createElement('option');
            city.setAttribute("id", bindings[i].label.value);
            city.setAttribute("value", bindings[i].label.value);
            city.appendChild(document.createTextNode(bindings[i].label.value));
            list.appendChild(city);
        }

        container.appendChild(list);
    });
}

function getSelectedCountry() {
    var countries = document.getElementById('countriesList');
    var country = countries.options[countries.selectedIndex].id;
    getAllCities(country);
}

function getSelectedCity() {
    var cities = document.getElementById('citiesList');
    var city = cities.options[cities.selectedIndex].id;
    window.location.href = "city.php?city=" + city;
}

function getUrlVars() {
    var vars = {};
    window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
        vars[key] = value;
    });
    return vars;
}

function getCityInfo() {
    var cityNameElement = document.getElementById('cityName');
    var cityName = cityNameElement ? cityNameElement.value : getUrlVars()["city"];

    if (!cityName) {
        window.location.href = "index.php";
        return;
    }

    var body = document.getElementById('body');
    if (body) {
        body.setAttribute("about", "dbr:" + cityName);
    }

    // Prepare table headers dynamically
    var tableHead = document.getElementById('tableHead');
    if (tableHead) {
        tableHead.innerHTML = "";

        var tableTitle = document.createElement('tr');
        var tableTitleCell = document.createElement('th');
        tableTitleCell.setAttribute("colspan", 6);
        tableTitleCell.setAttribute("class", "text-center text-uppercase font-weight-bold py-3");
        tableTitleCell.setAttribute("property", "rdfs:label");
        tableTitleCell.appendChild(document.createTextNode(cityName));
        tableTitle.appendChild(tableTitleCell);
        tableHead.appendChild(tableTitle);

        var tableAttributes = document.createElement('tr');
        var headers = ["Bike station Name", "Location", "Available bikes", "Free spots", "Total capacity", "Payment"];
        headers.forEach(function(headerText) {
            var th = document.createElement('th');
            th.appendChild(document.createTextNode(headerText));
            tableAttributes.appendChild(th);
        });
        tableHead.appendChild(tableAttributes);
    }

    // SPARQL query with corrected URI scheme (http://www.example.com/)
    var query = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" +
        " SELECT DISTINCT ?label ?lat ?long ?available ?free ?total ?cardPaiement WHERE {" +
        " ?city rdfs:label \"" + cityName + "\" ." +
        " ?city <http://www.example.com/bikeStations> ?bikeStation ." +
        " ?bikeStation rdfs:label ?label ." +
        " ?bikeStation <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ." +
        " ?bikeStation <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long ." +
        " ?bikeStation <http://www.example.com/available> ?available ." +
        " ?bikeStation <http://www.example.com/free> ?free ." +
        " ?bikeStation <http://www.example.com/total> ?total ." +
        " ?bikeStation <http://www.example.com/cardPaiement> ?cardPaiement ." +
        "} " +
        " ORDER BY ?label";

    var responseUrl = getFusekiUrl() + "?query=" + encodeURIComponent(query) + "&output=json";

    $.getJSON(responseUrl, function (jsonData) {
        var bindings = jsonData.results.bindings;
        var tableBody = document.getElementById('tableBody');

        if (!tableBody) return;
        tableBody.innerHTML = "";

        if (bindings.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No bike station data found in Fuseki for <strong>' + cityName + '</strong></td></tr>';
            return;
        }

        for (var i = 0; i < bindings.length; i++) {
            var bikeStation = document.createElement('tr');
            bikeStation.setAttribute("about", "ex:" + cityName + (i + 1));

            /* Station Name */
            var bikeStationName = document.createElement('td');
            bikeStationName.setAttribute("property", "rdfs:label");
            bikeStationName.appendChild(document.createTextNode(bindings[i].label.value));
            bikeStation.appendChild(bikeStationName);

            /* Coordinates Location */
            var bikeStationLocation = document.createElement('td');
            bikeStationLocation.appendChild(document.createTextNode(bindings[i].lat.value + ", " + bindings[i].long.value));
            bikeStation.appendChild(bikeStationLocation);

            /* RDFa Hidden Lat & Lon */
            var lat = document.createElement('td');
            lat.setAttribute("property", "geo:lat");
            lat.setAttribute("datatype", "xsd:decimal");
            lat.appendChild(document.createTextNode(bindings[i].lat.value));
            lat.style.display = "none";
            bikeStation.appendChild(lat);

            var lon = document.createElement('td');
            lon.setAttribute("property", "geo:long");
            lon.setAttribute("datatype", "xsd:decimal");
            lon.appendChild(document.createTextNode(bindings[i].long.value));
            lon.style.display = "none";
            bikeStation.appendChild(lon);

            /* Available Bikes */
            var bikeStationAvailable = document.createElement('td');
            bikeStationAvailable.setAttribute("property", "ex:available");
            bikeStationAvailable.setAttribute("datatype", "xsd:integer");
            bikeStationAvailable.appendChild(document.createTextNode(bindings[i].available.value));
            bikeStation.appendChild(bikeStationAvailable);

            /* Free Spots */
            var bikeStationFree = document.createElement('td');
            bikeStationFree.setAttribute("property", "ex:free");
            bikeStationFree.setAttribute("datatype", "xsd:integer");
            bikeStationFree.appendChild(document.createTextNode(bindings[i].free.value));
            bikeStation.appendChild(bikeStationFree);

            /* Total Spots */
            var bikeStationTotal = document.createElement('td');
            bikeStationTotal.setAttribute("property", "ex:total");
            bikeStationTotal.setAttribute("datatype", "xsd:integer");
            bikeStationTotal.appendChild(document.createTextNode(bindings[i].total.value));
            bikeStation.appendChild(bikeStationTotal);

            /* Payment Badge */
            var bikeStationPaiement = document.createElement('td');
            var isCard = bindings[i].cardPaiement.value === "1";
            bikeStationPaiement.innerHTML = isCard
                ? '<span class="badge badge-success">Card accepted</span>'
                : '<span class="badge badge-secondary">Card not accepted</span>';
            bikeStation.appendChild(bikeStationPaiement);

            /* RDFa Hidden Payment */
            var cardPaiement = document.createElement('td');
            cardPaiement.setAttribute("property", "ex:cardPaiement");
            cardPaiement.setAttribute("datatype", "xsd:integer");
            cardPaiement.appendChild(document.createTextNode(bindings[i].cardPaiement.value));
            cardPaiement.style.display = "none";
            bikeStation.appendChild(cardPaiement);

            tableBody.appendChild(bikeStation);
        }

        pagination(bindings.length);
    }).fail(function (jqXHR, textStatus, errorThrown) {
        var tableBody = document.getElementById('tableBody');
        if (tableBody) {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-4">Failed to reach the Fuseki endpoint at ' + getFusekiUrl() + '. Check if Fuseki is running and reachable from this machine.</td></tr>';
        }
    });
}

function cityAlreadyExists() {
    alert('This city already exists in the triplestore with real time data, please choose another one');
    window.location.href = "index.php";
}
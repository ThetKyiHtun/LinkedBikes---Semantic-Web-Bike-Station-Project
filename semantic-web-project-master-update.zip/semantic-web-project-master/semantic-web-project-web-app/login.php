<?php
require_once 'auth.php';

$error = null;
if (is_admin_logged_in()) {
    header('Location: admin.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? (string)$_POST['password'] : '';

    $config = dirname(__DIR__) . '/admin_config.php';
    if (is_file($config)) {
        include $config;
    }

    $validName = isset($admin_username) && hash_equals($admin_username, $username);
    $validPass = isset($admin_password_hash) && password_verify($password, $admin_password_hash);

    if ($validName && $validPass) {
        session_regenerate_id(true);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        header('Location: admin.php');
        exit();
    }

    $error = 'Invalid username or password. Please try again.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedBikes - Admin Login</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vendor/css/all.min.css?v=3">
    <link rel="stylesheet" href="vendor/css/bootstrap.min.css?v=3">
    <link rel="stylesheet" href="css/style.css?v=4">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <span class="brand-icon"><i class="fa-solid fa-bicycle"></i></span>
                <span>LinkedBikes<small>Smart Bike Explorer</small></span>
            </a>
            <div class="ml-auto">
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill">
                    <i class="fa-solid fa-house mr-1"></i> Home
                </a>
            </div>
        </div>
    </nav>

    <header class="hero hero-sm">
        <i class="fa-solid fa-user-shield hero-ghost"></i>
        <h1><i class="fa-solid fa-lock mr-2"></i>Admin Login</h1>
        <p>Sign in with an administrator account to manage and add data.</p>
    </header>

    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card">
                    <div class="card-header-custom">
                        <span class="section-icon icon-slate"><i class="fa-solid fa-user-lock"></i></span>
                        <h2>Administrator Access</h2>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($error !== null) { ?>
                            <div class="alert alert-danger py-2 small">
                                <i class="fa-solid fa-circle-exclamation mr-1"></i><?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php } ?>

                        <form method="POST" action="login.php">
                            <div class="form-group">
                                <label for="username" class="font-weight-600 text-dark small mb-1">Username</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter admin username" autocomplete="username" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password" class="font-weight-600 text-dark small mb-1">Password</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-key"></i></span>
                                    </div>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter admin password" autocomplete="current-password" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary-custom btn-block mt-4">
                                <i class="fa-solid fa-right-to-bracket mr-1"></i> Sign In
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <i class="fa-solid fa-bicycle mr-1"></i> LinkedBikes &middot; Developed By UCSY Master Students
    </footer>

</body>
</html>
package FileReader;

import Models.BikeStation;
import Models.City;
import RDFGenerator.RDFGenerator;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserFilesParser {

    /* Method that return all file names from a selected directory
    * taken from Stackoverflow */
    public List<String> listFilesForFolder(final File folder) {
        List<String> files = new ArrayList();
        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                listFilesForFolder(fileEntry);
            } else {
                files.add(fileEntry.getName());
            }
        }
        return files;
    }

    public void csvParser (List<String> files) {
        RDFGenerator rdfGenerator = new RDFGenerator();

        for (int i = 0; i < files.size(); i++) {
            String csvFile = files.get(i);

            try {
                BufferedReader br = null;
                String line = "";
                String csvSplitBy = ",";

                City city = new City();
                String[] cityNameCountry = csvFile.split("::");
                if (cityNameCountry.length < 2) {
                    System.err.println("-> Skipping '" + csvFile + "': file name must be 'Country::City.txt'.");
                    continue;
                }
                city.setCountry(cityNameCountry[0]);
                city.setName(cityNameCountry[1].replace(".txt", ""));

                List<BikeStation> bikeStations = new ArrayList<BikeStation>();

                try {
                    String directory = System.getProperty("user.dir") + "/Manually-added-files/";
                    br = new BufferedReader(new FileReader(directory + csvFile));
                    while ((line = br.readLine()) != null) {
                        if (line.trim().isEmpty()) continue;
                        String[] cityInfo = line.split(csvSplitBy);
                        if (cityInfo.length < 7) {
                            System.err.println("-> Skipping malformed row in '" + csvFile + "': " + line);
                            continue;
                        }

                        BikeStation bikeStation = new BikeStation();
                        bikeStation.setName(cityInfo[0]);
                        bikeStation.setLattitude(cityInfo[1].replace(" ", ""));
                        bikeStation.setLongitude(cityInfo[2].replace(" ", ""));
                        bikeStation.setAvailable(cityInfo[3].replace(" ", ""));
                        bikeStation.setFree(cityInfo[4].replace(" ", ""));
                        bikeStation.setTotal(cityInfo[5].replace(" ", ""));
                        bikeStation.setCardPaiement(cityInfo[6].replace(" ", ""));

                        bikeStations.add(bikeStation);
                    }
                    city.setBikeStations(bikeStations);

                    /* Create RDF */
                    if (!bikeStations.isEmpty()) {
                        rdfGenerator.generateRDF(city);
                        System.out.println("-> Imported '" + city.getName() + "' (" + city.getCountry() + ") - " + bikeStations.size() + " stations.");
                    } else {
                        System.err.println("-> Skipping '" + csvFile + "': no station rows found.");
                    }
                }
                catch (FileNotFoundException e) {
                    System.err.println("-> File not found: " + csvFile);
                }
                catch (IOException e) {
                    System.err.println("-> Error reading '" + csvFile + "': " + e.getMessage());
                }
                finally {
                    if (br != null) {
                        try {
                            br.close();
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (Exception e) {
                /* Keep going: a single bad file must not abort the whole import. */
                System.err.println("-> Failed to import '" + csvFile + "': " + e.getMessage());
            }

        }
    }
}

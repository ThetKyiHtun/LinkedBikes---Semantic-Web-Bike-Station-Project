package Main;

import Constants.Constants;
import FileReader.UserFilesParser;
import org.apache.jena.rdfconnection.RDFConnection;
import org.apache.jena.rdfconnection.RDFConnectionFactory;

import java.io.File;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println(" Starting RDF Triplestore Data Import ");
        System.out.println("==========================================");

        /* -------------------------------------------------------------------------
         * 1. Clear existing triplestore content before inserting new data
         * ------------------------------------------------------------------------- */
        System.out.println("\n[1/2] Connecting to triplestore at: " + Constants.triplestore);
        try (RDFConnection conn = RDFConnectionFactory.connect(Constants.triplestore)) {
            conn.delete();
            System.out.println("-> Triplestore cleared successfully.");
        } catch (Exception e) {
            System.err.println("-> Failed to clear triplestore: " + e.getMessage());
        }

        /* -------------------------------------------------------------------------
         * 2. Parse manually added CSV files
         * ------------------------------------------------------------------------- */
        System.out.println("\n[2/2] Processing user CSV files...");
        try {
            UserFilesParser fr = new UserFilesParser();
            String directory = System.getProperty("user.dir") + "/Manually-added-files";
            File folder = new File(directory);

            if (folder.exists() && folder.isDirectory()) {
                List<String> files = fr.listFilesForFolder(folder);
                if (files != null && !files.isEmpty()) {
                    fr.csvParser(files);
                    System.out.println("-> CSV files processed successfully.");
                } else {
                    System.out.println("-> No CSV files found in /Manually-added-files.");
                }
            } else {
                System.out.println("-> Directory '/Manually-added-files' does not exist. Skipping CSV parsing.");
            }
        } catch (Exception e) {
            System.err.println("-> Error processing CSV files: " + e.getMessage());
        }

        System.out.println("\n==========================================");
        System.out.println(" Import Finished! Triples uploaded to Fuseki. ");
        System.out.println("==========================================");
    }
}
<?php
$admin_username = 'admin';
$admin_password_hash = '$2y$12$WVELvQ3Ntxt/k5th1uQJ9uzOsteM1UKIiFj6Tqo/aLlGns.OA5hTG';